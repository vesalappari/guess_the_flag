# guess_the_flag
 Game for guessing the country's flag - Javascript, html and css - Low level code
 html in root and css, img, js and json files in their folders

    Supports english and finnish languages

    This project contains the flags of all 254 countries downloaded from https://flagpedia.net/download/images on 14th of february in 2025. Some country codes have same flag (Norway, Bouvet island and Svalbard and Jan Mayen)

    Background image designed by starline / Freepik http://www.freepik.com

    Idea of this game is to guess corrrect countries of five randomly selected flag
